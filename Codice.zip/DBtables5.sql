Drop database if Exists CFUValidatorDB;
Create database CFUValidatorDB; /* It is a synonym for CREATE SCHEMA*/
Use CFUValidatorDB;

Create Table student (
    stud_email Varchar(40) Not Null,
    stud_password Varchar(30) Not Null,
    stud_fiscalCode Varchar(30) Not Null,
    stud_name Varchar(30) Not Null,
    stud_surname Varchar(30) Not Null,
    stud_sex Varchar(20) Not Null,
    stud_birthday Date Not Null,
    stud_birthplace Varchar(100) Not Null,
    stud_residence Varchar(100) Not Null,
    stud_phone Varchar(15) Not Null,
    Primary Key (stud_email)
    );

Create Table secretary (
    sec_email Varchar(40) Not Null,
    sec_password Varchar(30) Not Null,
    sec_fiscalCode Varchar(30) Not Null,
    sec_name Varchar(30) Not Null,
    sec_surname Varchar(30) Not Null,
    sec_sex Varchar(20) Not Null,
    sec_birthday Date Not Null,
    sec_birthplace Varchar(100) Not Null,
    sec_residence Varchar(100) Not Null,
    sec_phone Varchar(15) Not Null,
    sec_office Varchar(50) Not Null,
    Primary Key (sec_email)
    );
    
Create Table council (
	coun_email Varchar(40) Not Null,
    coun_password Varchar(30) Not Null,
    coun_fiscalCode Varchar(30) Not Null,
    coun_name Varchar(30) Not Null,
    coun_surname Varchar(30) Not Null,
    coun_sex Varchar(20) Not Null,
    coun_birthday Date Not Null,
    coun_birthplace Varchar(100) Not Null,
    coun_residence Varchar(100) Not Null,
    coun_phone Varchar(15) Not Null,
    coun_role Varchar(30) Not Null,
    coun_function Varchar(30) Not Null,
    Primary Key (coun_email)
    );
	
Create Table request(
	req_id int Not Null auto_increment,
    req_state Varchar(30) Not Null,
    student_email Varchar(40) Not Null,
    requestType Varchar(20) Not Null,
    Primary Key(req_id),
    Foreign Key(student_email) References student (stud_email)
    On Update cascade On Delete cascade
    );
    
/*version without auto_increment in ec_id and ja_id*/
/*cert_file and job_file contain the file paths, not the file itself*/
Create Table english_certification(
	ec_id int Not Null,
    s_name Varchar(30) Not Null,
    s_surname Varchar(30) Not Null,
    cert_type Varchar(40) Not Null,
    cefr_level Varchar(10) Not Null,
    cert_seat Varchar(40) Not Null,
    cert_date Date Not Null,
    cert_file Varchar(600) Not Null,
    Primary Key (ec_id),
    Foreign Key(ec_id) References request(req_id)
    On Update cascade On Delete cascade
    );
    
Create Table job_activity(
	ja_id int Not Null,
    st_name Varchar(30) Not Null,
    st_surname Varchar(30) Not Null,
    st_birthday Date Not Null,
    st_birthplace Varchar(100) Not Null,
    st_email Varchar(40) Not Null,
    st_phone Varchar(15) Not Null,
    st_degree_course Varchar(30) Not Null,
    st_residence Varchar(100) Not Null,
    company_name Varchar(50) Not Null,
    company_address Varchar(200) Not Null,
    ja_profile Varchar(30) Not Null,
    contract_type Varchar(40) Not Null,
    first_day Date Not Null,
    last_day Date Not Null,
    work_hours int Not Null,
    ja_file Varchar(600) Not Null,
    Primary Key (ja_id),
    Foreign Key(ja_id) References request(req_id)
    On Update cascade On Delete cascade
    );
/*version without auto_increment in request_id*/
/*email_student has a reference to stud_email. Done for make easier to find association among
student, request and notification */
/*flag is a control. When flag is setted on yes then the notification 
hasn't been displayed yet. It's possible to have more notification for one request*/

Create Table notification(
	not_id int Not Null auto_increment,
    request_id int Not Null,
    email_student Varchar(40) Not Null,
	notificationType Varchar(20) Not Null,
    not_flag Varchar(10) Not Null,
    not_title Varchar(100) Not Null,
    not_object Varchar(100) Not Null,
    not_date Date Not Null,
    not_details Varchar(600) Not Null,
    Primary Key(not_id),
    Foreign Key(request_id) References request(req_id)
    On Update cascade On Delete cascade,
    Foreign Key(email_student) References student(stud_email)
    On Update cascade On Delete cascade
 );
 
