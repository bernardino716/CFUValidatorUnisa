Insert Into student(stud_email,stud_password,stud_fiscalCode,stud_name,stud_surname,stud_sex,stud_birthday,stud_birthplace,stud_residence,stud_phone)
	values ('studente1@gmail.com','passprova1','SGGMNL50A01A566U','a','a','m','1999-11-1','a','a','1111111123431');

Insert Into secretary(sec_email,sec_password,sec_fiscalCode,sec_name,sec_surname,sec_sex,sec_birthday,sec_birthplace,sec_residence,sec_phone,sec_office)
	values ('segreteria1@gmail.com','passprova1','SGGMNL50A01A566U','a','a','m','1999-11-1','a','a','1111111123431','aaaaaaaa');
    
Insert Into council(coun_email,coun_password,coun_fiscalCode,coun_name,coun_surname,coun_sex,coun_birthday,coun_birthplace,coun_residence,coun_phone,coun_role,coun_function)
	values ('consiglio1@gmail.com','passprova1','SGGMNL50A01A566U','a','a','m','1999-11-1','a','a','1111111123431','aaaaaaaaaa','aaa');    
    
Insert Into request(req_id,req_state,student_email,requestType)
	values (1,'confermata',(Select stud_email From student Where stud_email='studente1@gmail.com'),'EnglishCertification');
    
Insert Into english_certification(ec_id,s_name,s_surname,cert_type,cefr_level,cert_seat,cert_date,cert_file)
	values ((Select req_id From request Where req_id=1),'aaaaaaa','aaaaaaASAS','dfd','a','m','1999-11-1','a');    
  
 Insert Into request(req_id,req_state,student_email,requestType)
	values (2,'rifiutata',(Select stud_email From student Where stud_email='studente1@gmail.com'),'EnglishCertification'); 
    
Insert Into english_certification(ec_id,s_name,s_surname,cert_type,cefr_level,cert_seat,cert_date,cert_file)
	values ((Select req_id From request Where req_id=2),'aaaaaaa','aaaaaaASAS','a','a','m','1999-11-1','a');    
 
Insert Into request(req_id,req_state,student_email,requestType)
	values (3,'confermata',(Select stud_email From student Where stud_email='studente1@gmail.com'),'JobActivity'); 
    
Insert Into job_activity(ja_id,st_name,st_surname,st_birthday,st_birthplace,st_email,st_phone,st_degree_course,st_residence,company_name,company_address,ja_profile,contract_type,first_day,last_day,work_hours,ja_file)
	values ((Select req_id From request Where req_id=3), 'bernardino','sagliocca','1999-11-11','aaaaaaaaaa','xxx@gmail.it','1111111121212','aaaa','aaa','m','aaaa','aaa','m','1999-11-11','1999-12-30',50,'aaaaaa');    
  
Insert Into request(req_id,req_state,student_email,requestType)
	values (4,'approvata',(Select stud_email From student Where stud_email='studente1@gmail.com'),'JobActivity'); 
    
Insert Into job_activity(ja_id,st_name,st_surname,st_birthday,st_birthplace,st_email,st_phone,st_degree_course,st_residence,company_name,company_address,ja_profile,contract_type,first_day,last_day,work_hours,ja_file)
	values ((Select req_id From request Where req_id=4), 'bernardino','sagliocca','1999-11-11','aaaaaaaaaa','xxx@gmail.it','1111111121212','aaaa','aaa','m','aaaa','aaa','m','1999-11-11','1999-12-30',50,'aaaaaa');    
  
Insert Into notification(not_id,request_id,email_student,notificationType,not_flag,not_title,not_object,not_date,not_details)
	values (1,(Select req_id From request Where req_id=1),(Select stud_email From student Where stud_email='studente1@gmail.com'),'EnglishCertification','unread','title1','object1','1999-11-1','details1');
    
 Insert Into notification(not_id,request_id,email_student,notificationType,not_flag,not_title,not_object,not_date,not_details)
	values (2,(Select req_id From request Where req_id=2),(Select stud_email From student Where stud_email='studente1@gmail.com'),'EnglishCertification','unread','title2','object2','1999-11-1','details2');   